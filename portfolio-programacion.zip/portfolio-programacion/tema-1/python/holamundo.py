print ("hola mundo")
